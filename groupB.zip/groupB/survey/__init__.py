from otree.api import *


doc = """
Your app description
"""


class C(BaseConstants):
    NAME_IN_URL = 'survey'
    PLAYERS_PER_GROUP = None
    NUM_ROUNDS = 1


class Subsession(BaseSubsession):
    pass


class Group(BaseGroup):
    pass


class Player(BasePlayer):
    
    age = models.IntegerField(label="How old are you?", min=18, max=145)
    sex = models.IntegerField(label="What is your legal gender?",
                              choices = [[1,'Female'],[2,'Male']]
                              )
    edu = models.IntegerField(label="What is your highest education level?",
                              choices= [[1,'High school or below'],
                                          [2,'Undergraduate'],[3,'Graduate']]
                                )
    work = models.IntegerField(label="How long have you been working?", 
                               choices = [[1, 'Less than 1 year'],
                                          [2, '1-3 years'],
                                          [3, '3-5 years'],
                                          [4, 'more than 5 years']],
                               widget=widgets.RadioSelectHorizontal
                               )


# PAGES
class Survey(Page):
    
    form_model = 'player'
    form_fields = ['age','sex','edu','work']


# class ResultsWaitPage(WaitPage):
#     pass


# class Finished(Page):
#     pass


page_sequence = [Survey]
