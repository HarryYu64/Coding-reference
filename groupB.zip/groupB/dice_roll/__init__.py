from otree.api import *


doc = """
Your app description
"""


class C(BaseConstants):
    NAME_IN_URL = 'dice_roll'
    PLAYERS_PER_GROUP = None
    NUM_ROUNDS = 5


class Subsession(BaseSubsession):
    pass


class Group(BaseGroup):
    pass


class Player(BasePlayer):
    
    
    # ans_list = []
    answer = models.IntegerField(label="what number did you rolled?",
                                 choices = [[1,'1'],[2,'2'],[3,'3'],[4,'4'],
                                            [5,'5'],[6,'6']],
                                 widget=widgets.RadioSelectHorizontal
                                 )
    # ans_list.append(answer)


# PAGES
class Insturction_dice(Page):
    @staticmethod
    
    # only display the instruction page at the first round
    def is_displayed(player: Player):
        
        return player.round_number == 1


# class ResultsWaitPage(WaitPage):
#     pass


class Dice_roll(Page):
    
    form_model = 'player'
    form_fields = ['answer']



def SetPayoff(player: Player):
    
    import numpy as np
    
    random_num = np.random.randint(1, C.NUM_ROUNDS + 1)
    
    if C.NUM_ROUNDS == random_num:
        
        payoff = answer
        
    return payoff
    
    

class Finished_dice(Page):
    @staticmethod
    
    # only display the result page at the last round
    def is_displayed(player: Player):
        
        return player.round_number == C.NUM_ROUNDS
    
    
    
    # player.payoff = SetPayoff()
    
    def before_next_page(player: Player, timeout_happened):
        
        import numpy as np
        
        # randomly pick one round to give payoff
        
        
        playing_round = np.random.randint(1, C.NUM_ROUNDS + 1)
        
        print(playing_round)
        
        
        
page_sequence = [Insturction_dice, Dice_roll, Finished_dice]
