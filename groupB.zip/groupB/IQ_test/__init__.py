from otree.api import *


doc = """
Your app description
"""


class C(BaseConstants):
    NAME_IN_URL = 'IQ_test'
    PLAYERS_PER_GROUP = None
    NUM_ROUNDS = 15


class Subsession(BaseSubsession):
    pass
    
    # import itertools
    # pressures = itertools.cycle([True, False])
    # for player in subsession.get_players():
    #     player.time_pressure = next(pressures)


class Group(BaseGroup):
    pass


class Player(BasePlayer):
    
    
    #Below we defined an integer variable for the IQ test 1.
    answer = models.IntegerField(label="Which one is the correct answer?",
                                choices = [[1,'1'],[2,'2'],[3,'3'],[4,'4'],
                                           [5,'5'],[6,'6'],[7,'7'], [8,'8']],
                                widget=widgets.RadioSelectHorizontal
                                )
    


################ PAGES ###################
class Instructions_IQ(Page):
    
    @staticmethod
    
    # only display the instruction page at the first round
    def is_displayed(player: Player):
        
        return player.round_number == 1



class IQ_T1(Page):
    
    form_model = 'player'
    form_fields = ['answer']
    
    
class Computations(Page):
    
    @staticmethod
    
    # only display the result page at the last round
    def is_displayed(player: Player):
        
        return player.round_number == C.NUM_ROUNDS
    


    def before_next_page(player: Player, timeout_happened):
        
        import numpy as np
        
        # randomly pick one round to give payoff
        
        
        playing_round = np.random.randint(1, C.NUM_ROUNDS + 1)
        
        print(playing_round)
        
        correct_answer = [8, 5, 1, 6, 3,
                          4, 3, 7, 8, 6,
                          1, 2, 6, 5, 1]
        
        if player.in_round(playing_round).answer == correct_answer[playing_round - 1]:
            
            player.payoff += 5
            
        else:
            
            player.payoff = 2
        
        
        correct_count = 0
        
        for i in range(1,16):
            
            if player.in_round(i).answer == correct_answer[i-1]:
                
                correct_count += 1
    
    

    
    
class Results_IQ(Page):
    
    @staticmethod
    
    # only display the result page at the last round
    def is_displayed(player: Player):
        
        return player.round_number == C.NUM_ROUNDS
    
    


page_sequence = [Instructions_IQ, IQ_T1, Computations, Results_IQ]







